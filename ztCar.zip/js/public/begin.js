$(function(){
    $("button").on("click",function(){
        window.location.href="occupation.html"
    })
})