$(function(){
    $(".rcord").on("click",function(){
        window.location.href="repayDetail.html"
    })
})