$(function(){
    $(".loan").on("click",function(){
        window.location.href="loanRcord.html"
    })
    $(".repay").on("click",function(){
        window.location.href="repayRcord.html"
    })
})